-- Thanks to sayclub!

if GetLocale() == "koKR" then
	BUYEMALL_LOCALS = {
	MAX 			= "최대",
	STACK 			= "세트",
	CONFIRM 		= "정말로 당신은 다음과 같이 구매를 희망하십니까?\n[%d 개 × %s 아이템]",
	STACK_PURCH		= "세트 구입",
	STACK_SIZE 		= "세트 수량",
	PARTIAL 		= "부분 세트 구입",
	MAX_PURCH		= "최고 구입",
	FIT				= "구입 가능 수량",
	AFFORD			= "현재 자산으로 구입 가능 수량",
	AVAILABLE		= "최대 판매 수량",
}
end

local L = BUYEMALL_LOCALS;
