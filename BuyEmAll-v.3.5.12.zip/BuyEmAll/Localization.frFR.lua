-- Thanks to Layrajha!

if GetLocale() == "frFR" then
	BUYEMALL_LOCALS = {
	-- MAX 			= "Max",
	STACK 			= "Pile",
	CONFIRM 		= "Voulez-vous vraiment acheter\n %d × %s?",
	-- STACK_PURCH	= "Stack Purchase",
	STACK_SIZE	 	= "Taille de pile",
	-- PARTIAL 		= "Partial stack",
	MAX_PURCH		= "Achat maximum",
	FIT				= "Vous pouvez transporter",
	AFFORD			= "Vous pouvez payer",
	AVAILABLE		= "Le marchand a",
}
end

local L = BUYEMALL_LOCALS;
